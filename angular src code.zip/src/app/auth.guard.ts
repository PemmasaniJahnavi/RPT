import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService } from './Services/auth.service';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
  constructor(private router: Router, private authService: AuthService) {}

  canActivate(): boolean {
    const token = this.authService.getToken();

    if (!token || token.trim().length < 10) { 
      console.warn('Unauthorized access attempt! Redirecting to login.');
      this.router.navigate(['/login']).then(() => {
        window.location.reload(); // 🔥 Forces full authentication check on navigation
      });
      return false;
    }

    console.log('Token verified. Access granted.');
    return true;
  }
}
