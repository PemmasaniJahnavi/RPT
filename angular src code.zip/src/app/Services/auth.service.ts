import { Injectable, PLATFORM_ID, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { User } from '../Models/user.model';
import { isPlatformBrowser } from '@angular/common';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private apiUrl = 'http://localhost:5111/api';

  constructor(private http: HttpClient, private router: Router, @Inject(PLATFORM_ID) private platformId: object) {}

  login(user: User): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/login`, user);
  }

 storeSessionData(profile: any): void {
  if (isPlatformBrowser(this.platformId) && profile && profile.token && profile.token.length > 10) {
    sessionStorage.setItem('profile', JSON.stringify(profile));
    sessionStorage.setItem('token', profile.token);
    console.log('Session data stored successfully:', profile);
  } else {
    console.error('Invalid profile data, authentication blocked.');
    sessionStorage.clear(); 
  }
}


  getToken(): string | null {
    if (isPlatformBrowser(this.platformId)) {
      return sessionStorage.getItem('token');
    }
    return null;
  }

  logout(): void {
    if (isPlatformBrowser(this.platformId)) {
      sessionStorage.clear();
    }
    this.router.navigate(['/login']);
  }

  isAuthenticatedAsync(): Observable<boolean> {
    const token = this.getToken();
    console.log('Validating token:', token);
    return of(token !== null && token !== '');
  }
}
