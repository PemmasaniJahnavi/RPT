import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Goal } from '../Models/goal.model';

@Injectable({
  providedIn: 'root'
})
export class GoalService {
  private apiUrl = 'http://localhost:5111/api/goal';

  constructor(private http: HttpClient) {}

  getGoal(profileId: number): Observable<Goal> {
    return this.http.get<Goal>(`${this.apiUrl}/fetch/${profileId}`);
  }
   createGoal(goal: Goal): Observable<Goal> {
    return this.http.post<Goal>(`${this.apiUrl}/create`, goal);
  }
}
