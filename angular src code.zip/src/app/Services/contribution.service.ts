import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ContributionService {
  private baseUrl = 'http://localhost:5111/api/financialdata';

  constructor(private http: HttpClient) {}

  getMaxAllowedContribution(goalId: number): Observable<any> {
  return this.http.get(`${this.baseUrl}/maxAllowedContribution/${goalId}`);
}


  submitContribution(contribution: { GoalId: number; Month: number; Year: number; MonthlyInvestment: number }): Observable<string> {
    return this.http.post<string>(`${this.baseUrl}/create`, contribution, { responseType: 'text' as 'json' });
  }
}
