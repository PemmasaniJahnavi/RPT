import { Component, Input, OnChanges, SimpleChanges,EventEmitter, signal, Output } from '@angular/core';
import { ProgressService } from '../../Services/progress.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-user-progress',
  standalone: true,
  templateUrl: './userprogress.component.html',
  styleUrls: ['./userprogress.component.css'],
  imports: [CommonModule]
})
export class UserProgressComponent implements OnChanges {
  @Input() goal: any;
  @Output() goalProgressUpdated = new EventEmitter<boolean>();

  showProgressModal = signal(false); 
  progressPercentage: number = 0;
  progressMessage: string = ''; 
  goalReached = signal(false);


  constructor(private progressService: ProgressService) {}

  async ngOnChanges(changes: SimpleChanges) {
    if (changes['goal'] && this.goal?.goalId) {
      this.fetchUserProgress(); 
    }
  }

  fetchUserProgress() {
    if (!this.goal) return;

    this.progressService.getProgress(this.goal.goalId).subscribe({
      next: (res) => {
        this.progressPercentage = res.progressPercentage;; 
        this.updateProgressMessage(); 
        this.goalReached.set(this.progressPercentage === 100);
        this.goalProgressUpdated.emit(this.goalReached()); 
      },
      error: (err) => {
        console.error('Error fetching user progress:', err);
      }
    });
  }
   openProgressModal() {
    this.fetchUserProgress(); 
    this.showProgressModal.set(true);
  }

  closeModal() {
    this.showProgressModal.set(false); 
  }

  updateProgressMessage() {
    if (this.progressPercentage === 100) {
      this.progressMessage = "🎉 You successfully reached your goal!!";
    } else if (this.progressPercentage >= 75) {
      this.progressMessage = "🔥 Almost there! Keep contributing!";
    } else if (this.progressPercentage >= 50) {
      this.progressMessage = "✨ You’re making great progress!";
    } else if (this.progressPercentage >= 25) {
      this.progressMessage = "👏 Good start! Keep going!";
    } else {
      this.progressMessage = "🚀 Let's get started! Every step counts!";
    }
  }
}
