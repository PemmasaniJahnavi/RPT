import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../Services/auth.service';
import { User } from '../../Models/user.model';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username = '';
  password = '';
  showUsernameWarning = false;
  showPasswordWarning = false;
  errorMessage = '';

  constructor(private router: Router, private auth: AuthService) {}

  login(): void {
  this.errorMessage = '';

  if (!this.username.trim() || !this.password.trim()) {
    this.errorMessage = 'Username and Password are required.';
    return;
  }

  const credentials: User = {
    username: this.username.trim(),
    password: this.password
  };

  this.auth.login(credentials).subscribe({
    next: (res: any) => {
      if (res && res.profileId) {
        const fakeToken = `token-${res.profileId}-${new Date().getTime()}`;
        this.auth.storeSessionData({ ...res, token: fakeToken });

        console.log('Login successful! Navigating to home...');
        this.router.navigate(['/home']);
      } else {
        this.errorMessage = 'Invalid username or password.';
      }
    },
    error: (err) => {
      console.error('Login error:', err);

      if (err.status === 400) {
        this.errorMessage = err.error || 'Invalid request. Please enter a username and password.';
      } else if (err.status === 401) {
        this.errorMessage = 'Incorrect username or password.';
      } else if (err.status === 500) {
        this.errorMessage = 'An unexpected error occurred. Please try again later.';
      } else {
        this.errorMessage = 'Something went wrong. Please try again.';
      }
    }
  });
}

clearError(): void {
  if (this.username.trim() && this.password.trim()) {
    this.errorMessage = '';
  }
}

}
