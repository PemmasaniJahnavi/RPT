import { Component, Input, Output, EventEmitter } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { GoalService } from '../../Services/goal.service';
import { Goal } from '../../Models/goal.model';

@Component({
  selector: 'app-create-goal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './create-goal.component.html',
  styleUrls: ['./create-goal.component.css']
})
export class CreateGoalComponent {
  @Input() profile!: { profileId: number; age: number; firstName: string; lastName: string };
  @Output() goalCreated = new EventEmitter<Goal>();

  currentAge!: number;
  retirementAge!: number | null;
  targetSavings!: number | null;
  currentSavings!: number | null;
  showForm = false;
  isLoading = false;
  successMessage = '';
  allFieldsError = ''; 

  retirementAgeError = ''; 
  savingsError = '';
  tsavingsError = '';

  constructor(private goalService: GoalService) {}

  openForm() {
    this.showForm = true;
    this.successMessage = ''; 
    this.currentAge = this.profile.age; 
    this.clearErrors(); 
  }

  closeForm() {
    this.showForm = false; 
    this.retirementAge = null;
    this.targetSavings = null;
    this.currentSavings = null;
    this.clearErrors(); 
  }

  createGoal() {
    if (!this.validateInputs()) {
      this.allFieldsError = 'All fields are required.';
      return;
    }

    this.isLoading = true;
    const goal: Goal = {
      profileId: this.profile.profileId,
      currentAge: this.currentAge,
      retirementAge: this.retirementAge!,
      targetSavings: this.targetSavings!,
      currentSavings: this.currentSavings!,
    };

    this.goalService.createGoal(goal).subscribe({
      next: (createdGoal) => {
        this.goalCreated.emit(createdGoal);
        this.successMessage = 'Goal created successfully!';
        this.showForm = false;
      },
      error: () => {
        alert('Goal creation failed');
      },
      complete: () => {
        this.isLoading = false;
      }
    });
  }

  validateInputs(): boolean {
    let isValid = true;
    this.allFieldsError = ''; 

    if (!this.retirementAge || !this.targetSavings || this.currentSavings === null) {
      isValid = false;
    }

    if (this.retirementAge !== null && this.retirementAge <= this.currentAge) {
      this.retirementAgeError = 'Retirement age must be greater than current age.';
      isValid = false;
    } else {
      this.retirementAgeError = '';
    }

    if (this.targetSavings !== null && this.targetSavings <= 0) {
      this.tsavingsError = 'Target savings must be greater than zero.';
      isValid = false;
    } else {
      this.tsavingsError = '';
    }

    if (this.currentSavings !== null && this.targetSavings !== null && this.currentSavings > this.targetSavings) {
      this.savingsError = 'Current savings must be less than target savings.';
      isValid = false;
    } else {
      this.savingsError = '';
    }

    return isValid;
  }

  clearError(): void {
    this.allFieldsError = ''; 
  }

  clearErrors(): void {
    this.retirementAgeError = '';
    this.savingsError = '';
    this.allFieldsError = '';
  }
}
