import { AfterViewInit, Component, OnDestroy, OnInit } from '@angular/core';
import { GoalService } from '../../Services/goal.service';
import { CreateGoalComponent } from '../create-goal/create-goal.component';
import { CommonModule } from '@angular/common';
import { AddContributionComponent } from '../add-contribution/add-contribution.component';
import { UserProgressComponent } from '../userprogress/userprogress.component';
import { Router } from '@angular/router';
import { Goal } from '../../Models/goal.model';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CreateGoalComponent, CommonModule, AddContributionComponent, UserProgressComponent],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, AfterViewInit, OnDestroy {
  profile: any = null;
  goal: Goal | null = null;
  showCreateGoal = false;
  showProfileMenu = false;
  goalReached: boolean = false;

  private documentClickListener: any;

  constructor(private goalService: GoalService, private router: Router) {}


  ngOnInit(): void {
    this.loadProfile();
  }

  ngAfterViewInit(): void {
    this.documentClickListener = (event: Event) => {
      const target = event.target as HTMLElement;
      if (this.showProfileMenu && !target.closest('.profile-popup') && !target.closest('.profile-icon')) {
        this.showProfileMenu = false;
      }
    };
    document.addEventListener('click', this.documentClickListener);
  }

  ngOnDestroy(): void {
    if (this.documentClickListener) {
      document.removeEventListener('click', this.documentClickListener);
    }
  }

  loadProfile() {
    if (typeof window !== 'undefined') {
      const storedProfile = sessionStorage.getItem('profile');
      if (storedProfile) {
        try {
          this.profile = JSON.parse(storedProfile);
          if (this.profile?.profileId) {
            this.loadGoal(this.profile.profileId);
          } else {
            console.error('ProfileId is missing in stored profile');
          }
        } catch (error) {
          console.error('Failed to parse profile from sessionStorage:', error);
        }
      } else {
        console.warn('No profile found in sessionStorage');
      }
    }
  }


  loadGoal(profileId: number) {
    this.goalService.getGoal(profileId).subscribe({
      next: (goalData) => {
        if (goalData && goalData.goalId) {
          this.goal = goalData;
          this.showCreateGoal = false;
        } else {
          this.goal = null;
          this.showCreateGoal = true;
        }
      },
      error: (error) => {
        this.goal = null;
        this.showCreateGoal = true;
        // console.error('Error fetching goal:', error);
      }
    });
  }


  handleGoalCreated(createdGoal: Goal) {
    if (createdGoal && createdGoal.goalId) {
      this.goal = createdGoal;
      this.showCreateGoal = false;
    }
  }

  /** ✅ Track goal progress updates */
   onGoalProgressUpdated(goalReached: boolean) { 
    this.goalReached = goalReached; // ✅ Assign boolean value
  }

  /** ✅ Toggle profile menu visibility */
  toggleProfileMenu(event: Event) {
    event.stopPropagation();
    this.showProfileMenu = !this.showProfileMenu;
  }

  /** ✅ Logout and clear session data */
  logout() {
    sessionStorage.clear();
    this.router.navigate(['/login']);
  }
}
