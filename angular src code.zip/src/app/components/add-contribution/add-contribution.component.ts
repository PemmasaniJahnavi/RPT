import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ContributionService } from '../../Services/contribution.service';


@Component({
  selector: 'app-add-contribution',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './add-contribution.component.html',
  styleUrls: ['./add-contribution.component.css']
})

export class AddContributionComponent {
  
  @Input() goalId!: number;
  @Input() goalReached!: boolean;
  
  maxAllowedContribution: number = 0; 
  month: number | null = null;
  year: number | null = null;
  monthlyContribution: number | null = null;
  showForm: boolean = false;
  showModal: boolean = false;

  monthError: string = '';
  yearError: string = '';
  contributionError: string = '';
  allFieldsError: string = '';

  constructor(private contributionService: ContributionService) {}

  ngOnInit() {
    this.fetchMaxContribution();
  }

  fetchMaxContribution() {
    this.contributionService.getMaxAllowedContribution(this.goalId).subscribe({
      next: (data) => {
        this.maxAllowedContribution = data.maxAllowedContribution; 
      },
      error: (err) => console.error('Error fetching max contribution:', err)
    });
  }

  openForm() {
    this.showModal = true;
    this.showForm = true;
    this.clearErrors();
  }

  closeModal() {
    this.resetForm();
    this.showModal = false;
  }


  validateMonth() {
    this.monthError = ''; 
    const currentMonth = new Date().getMonth() + 1;
    const currentYear = new Date().getFullYear();

    if (this.month === null || isNaN(this.month)) {
      this.monthError = 'Month is required.';
    } else if (this.month < 1 || this.month > 12) {
      this.monthError = 'Month must be between 1–12.';
    }  else if (this.year !== null && !isNaN(this.year) && this.year === currentYear && this.month < currentMonth) {
      this.monthError = 'Cant make entry for previous months.';
    }

    this.clearAllFieldsError();
  }

  validateYear() {
    this.yearError = '';

    if (this.year === null || isNaN(this.year)) {
      this.yearError = 'Year is required.';
    } else if (this.year < 2025) {
      this.yearError = 'Year must be 2025 or later.';
    }

    this.clearAllFieldsError();
  }

  validateMonthlyContribution() {
    this.contributionError = '';

    if (this.monthlyContribution === null || isNaN(this.monthlyContribution)) {
      this.contributionError = 'Monthly contribution is required.';
    } else if (this.monthlyContribution <=0) {
      this.contributionError = 'Monthly contribution must be greater than zero.';
    } if (typeof this.maxAllowedContribution === 'number' && Number(this.monthlyContribution) > this.maxAllowedContribution) {
  this.contributionError = `Monthly contribution must be less than ${this.maxAllowedContribution}.`;
}

    this.clearAllFieldsError();
  }

  clearAllFieldsError() {
    if (this.month !== null && this.year !== null && this.monthlyContribution !== null) {
      this.allFieldsError = '';
    }
  }

  submitContribution() {
    if (!this.month || !this.year || !this.monthlyContribution) {
      this.allFieldsError = 'All fields are required.';
      return;
    }

    if (this.monthError || this.yearError || this.contributionError) return;

    const contribution = {
      GoalId: this.goalId,
      Month: this.month,
      Year: this.year,
      MonthlyInvestment: this.monthlyContribution
    };

    this.contributionService.submitContribution(contribution).subscribe({
      next: () => {
        this.resetForm();
        this.closeModal();
      },
      error: (err) => {
        this.handleBackendErrors(err.error);
      }
    });
  }

  handleBackendErrors(errorMessage: string) {
    this.clearErrors();

    if (errorMessage.includes('Goal ID must be greater than 0')) {
      this.allFieldsError = errorMessage;
    } else if (errorMessage.includes('Year must be 2025 or later')) {
      this.yearError = errorMessage;
    } else if (errorMessage.includes('Month must be between 1 and 12')) {
      this.monthError = errorMessage;
    } else if (errorMessage.includes('Month must be')) {
      this.monthError = errorMessage;
    } else if (errorMessage.includes('Monthly contribution must be <')) {
      this.contributionError = errorMessage;
    } else if (errorMessage.includes('Monthly contribution must be greater than zero')) {
      this.contributionError = errorMessage;
    } else {
      this.contributionError = errorMessage;
    }
  }

  clearErrors() {
    this.monthError = '';
    this.yearError = '';
    this.contributionError = '';
    this.allFieldsError = '';
  }

  resetForm() {
    this.month = null;
    this.year = null;
    this.monthlyContribution = null;
    this.showForm = false;
    this.clearErrors();
  }
}
