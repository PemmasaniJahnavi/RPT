export interface Goal {
  goalId?: number;
  profileId: number;
  currentAge: number;
  retirementAge: number;
  targetSavings: number;
  currentSavings: number;
  monthlyContribution?: number;
}