using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using RPT.Services;
using RPT.Repositories;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();

var configuration = builder.Configuration;
builder.Services.AddSingleton(configuration);

builder.Services.AddLogging();

builder.Services.AddScoped<IGoalService, GoalService>();
builder.Services.AddScoped<IProfileService, ProfileService>();
builder.Services.AddScoped<IFinancialYearDataService, FinancialYearDataService>();

builder.Services.AddScoped<IGoalRepo, GoalRepo>();
builder.Services.AddScoped<IProfileRepo, ProfileRepo>();
builder.Services.AddScoped<IFinancialRepo, FinancialRepo>();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();
