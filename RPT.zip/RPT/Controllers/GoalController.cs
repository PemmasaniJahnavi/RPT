using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RPT.Models;
using RPT.Services;

namespace RPT.Controllers;

[ApiController]
[Route("api/goal")]
public class GoalController : ControllerBase
{
    private readonly IGoalService _goalService;
    private readonly ILogger<GoalController> _logger;

    public GoalController(IGoalService goalService, ILogger<GoalController> logger)
    {
        _goalService = goalService;
        _logger = logger;
    }

[HttpPost("create")]
public async Task<IActionResult> CreateGoalAsync([FromBody] GoalDetails newGoal)
{
    _logger.LogInformation($"Received request to create goal for Profile ID: {newGoal.ProfileId}");

    if (newGoal == null || newGoal.ProfileId <= 0 || newGoal.CurrentAge <= 0 || newGoal.RetirementAge <= 0 ||newGoal.RetirementAge<=newGoal.CurrentAge
        ||newGoal.TargetSavings <= 0 || newGoal.CurrentSavings < 0)
    {
        _logger.LogWarning("Invalid input received.");
        return StatusCode(StatusCodes.Status400BadRequest,"Invalid input values. Please check!");
    }

    try
    {
        var success = await _goalService.CreateGoalAsync(newGoal);
        if (success)
        {
            _logger.LogInformation($"Goal creation success for {newGoal.ProfileId}.");      
            return StatusCode(StatusCodes.Status201Created, "Goal created successfully.");
        }

        _logger.LogWarning("Goal creation failed.");
        return StatusCode(StatusCodes.Status500InternalServerError, "Goal creation failed.");
    }
    catch (Exception ex)
    {
        _logger.LogError($"Exception: {ex.Message}");
        return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error.");
    }
}

    [HttpGet("fetch/{profileId}")]
public async Task<IActionResult> GetGoalAsync(int profileId)
{
    _logger.LogInformation($"Received request to fetch goal for Profile ID: {profileId}");
    
    if (profileId <= 0)
    {
        _logger.LogWarning("Invalid Profile ID.");
        return StatusCode(StatusCodes.Status400BadRequest,"Invalid Profile ID.");
    }

    try
    {
        var goal = await _goalService.GetGoalByIdAsync(profileId);
        if (goal != null)
        {
            _logger.LogInformation($"Fetching goal using {profileId} is successful");
            return StatusCode(StatusCodes.Status200OK,goal);
        }

        _logger.LogWarning($"No goal found for Profile ID: {profileId}");
        return StatusCode(StatusCodes.Status404NotFound,"Goal not found for given Profile ID.");
    }
    catch (Exception ex)
    {
        _logger.LogError($"Exception: {ex.Message}");
        return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error.");
    }
}
}
