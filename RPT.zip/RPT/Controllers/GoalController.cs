using Microsoft.AspNetCore.Mvc;
using RPT.Models;
using RPT.Services;

namespace RPT.Controllers;

[ApiController]
[Route("api/goal")]
public class GoalController : ControllerBase
{
    private readonly IGoalService _goalService;

    public GoalController(IGoalService goalService) => _goalService = goalService;

    [HttpGet("{id}")]
    public IActionResult GetGoal(int id) =>
        _goalService.GetGoalById(id) is Goal goal ? Ok(goal) : NotFound("Goal not found");

    [HttpPost]
    public IActionResult CreateGoal([FromBody] Goal newGoal) =>
        newGoal.GoalId != newGoal.ProfileId 
        ? BadRequest("Goal ID must match Profile ID") 
        : _goalService.CreateGoal(newGoal)? Ok("Goal created successfully"): NotFound("Creation failed");

    [HttpPut("{id}")]
    public IActionResult UpdateGoal(int id, [FromBody] Goal updatedGoal) =>
        id != updatedGoal.GoalId 
        ? BadRequest("Goal ID cannot be changed") 
        : _goalService.UpdateGoal(updatedGoal) ? Ok("Goal updated successfully") : NotFound("Goal not found");

    [HttpDelete("{id}")]
    public IActionResult DeleteGoal(int id) =>
        _goalService.DeleteGoal(id) ? Ok("Goal deleted successfully") : NotFound("Goal not found");

}
