using Microsoft.AspNetCore.Mvc;
using RPT.Models;
using RPT.Services;

namespace RPT.Controllers;

[ApiController]
[Route("api/financialdata")]
public class FinancialYearDataController : ControllerBase
{
    private readonly IFinancialYearDataService _financialService;

    public FinancialYearDataController(IFinancialYearDataService financialService)
    {
     _financialService = financialService;
    } 

    [HttpGet("{profileId}")]
    public IActionResult GetFinancialData(int profileId) =>
        _financialService.GetFinancialYearDataById(profileId) is FinancialYearData data ? Ok(data) : NotFound("No financial data found");

    [HttpPost]
    public IActionResult CreateFinancialData([FromBody] FinancialYearData newData)
    {
         if (newData == null)
        return BadRequest("Invalid input");

    var success = _financialService.CreateFinancialYearData(newData);
    return success ? Ok("Financial data created successfully") : BadRequest("Failed to create financial data");
    }

    [HttpPut("{id}")]
    public IActionResult UpdateFinancialData(int id, [FromBody] FinancialYearData updatedData) =>
        id != updatedData.Id 
        ? BadRequest("Financial Year Data ID cannot be changed") 
        : _financialService.UpdateFinancialYearData(updatedData) ? Ok("Financial data updated successfully") 
        : NotFound("Update failed");

    [HttpDelete("{id}")]
    public IActionResult DeleteFinancialData(int id) =>
        _financialService.DeleteFinancialYearData(id) ? Ok("Financial data deleted successfully") 
        : NotFound("Financial data not found");
}
