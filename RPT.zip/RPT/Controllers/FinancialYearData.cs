using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RPT.Models;
using RPT.Services;

namespace RPT.Controllers;

[ApiController]
[Route("api/financialdata")]
public class FinancialYearDataController : ControllerBase
{
    private readonly IFinancialYearDataService _financialService;
    private readonly ILogger<FinancialYearDataController> _logger;

    public FinancialYearDataController(IFinancialYearDataService financialService, ILogger<FinancialYearDataController> logger)
    {
        _financialService = financialService;
        _logger = logger;
    }

    [HttpPost("create")]
    public async Task<IActionResult> CreateFinancialDataAsync([FromBody] FinancialYearData newData)
    {
    _logger.LogInformation($"Received request to create financialyeardata for GoalID: {newData.GoalId}");

    if (newData == null ||newData.GoalId<=0|| newData.Year<=2024 || newData.Month<1 
    || newData.MonthlyInvestment<0 || newData.Month>12)
    {
        _logger.LogWarning("Invalid input received for CreateFinancialData.");
        return StatusCode(StatusCodes.Status400BadRequest, "Invalid input. Please Check!");
    }

    try
    {
        var success = await _financialService.CreateFinancialYearDataAsync(newData);
        if (success)
        {
            _logger.LogInformation("Creation of FinancialData successful.");
            return StatusCode(StatusCodes.Status201Created, "Financial data created successfully.");
        }
           
        _logger.LogError("Creation of FinancialData failed..");
        return StatusCode(StatusCodes.Status500InternalServerError, "Error in creation of financial data.");
    }
    catch (Exception ex)
    {
        _logger.LogError($"Exception in CreateFinancialData: {ex.Message}");
        return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error.");
    }
   }

[HttpGet("fetch/{goalId}")]
public async Task<IActionResult> GetFinancialDataByGoalIdAsync(int goalId)
{
    _logger.LogInformation($"Received request to fetch financialyeardata for GoalID: {goalId}");
    
    if (goalId <= 0)
    {
        _logger.LogWarning("Invalid goalId received.");
        return StatusCode(StatusCodes.Status400BadRequest, "GoalId invalid");     
    }

    try
    {
        var data = await _financialService.GetFinancialYearDataByGoalIdAsync(goalId);
        if (data != null && data.Any())
        {
            _logger.LogInformation("FinancialData fetch using goalId is successful.");
            return StatusCode(StatusCodes.Status200OK, data);
        }
        _logger.LogWarning("No FinancialData found with goalId");
        return StatusCode(StatusCodes.Status404NotFound, $"No financial data found for Goal ID: {goalId}");         
    }
    catch (Exception ex)
    {
        _logger.LogError($"Exception: {ex.Message}");
        return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error.");
    }
}
}
