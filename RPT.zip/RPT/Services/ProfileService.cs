using Microsoft.Extensions.Logging;
using RPT.Models;
using RPT.Repositories;

namespace RPT.Services;

public class ProfileService : IProfileService
{
    private readonly IProfileRepo _profileRepository;
    private readonly ILogger<ProfileService> _logger;

    public ProfileService(IProfileRepo profileRepository, ILogger<ProfileService> logger)
    {
        _profileRepository = profileRepository;
        _logger = logger;
    }

    public async Task<Profile?> LoginAsync(string username, string password)
    {
      
    _logger.LogInformation($"Attempting login for username: {username}");
    return await _profileRepository.LoginAsync(username, password);
    
    }

}
