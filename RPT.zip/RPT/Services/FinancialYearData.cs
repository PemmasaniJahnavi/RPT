using Microsoft.Extensions.Logging;
using RPT.Models;
using RPT.Repositories;

namespace RPT.Services;

public class FinancialYearDataService : IFinancialYearDataService
{
    private readonly IFinancialRepo _financialYearDataRepository;
    private readonly ILogger<FinancialYearDataService> _logger;

    public FinancialYearDataService(IFinancialRepo financialYearDataRepository, ILogger<FinancialYearDataService> logger)
    {
        _financialYearDataRepository = financialYearDataRepository;
        _logger = logger;
    }

    public async Task<bool> CreateFinancialYearDataAsync(FinancialYearData financialData)
   {

    _logger.LogInformation($"Attempting to create financial year data for Goal ID: {financialData.GoalId}");
    return await _financialYearDataRepository.CreateFinancialYearDataAsync(financialData);
   }

public async Task<IEnumerable<FinancialData>> GetFinancialYearDataByGoalIdAsync(int goalId)
{
    
    _logger.LogInformation($"Attempting to fetch financial year data for Goal ID: {goalId}");
    return await _financialYearDataRepository.GetFinancialYearDataByGoalIdAsync(goalId);
}
}
