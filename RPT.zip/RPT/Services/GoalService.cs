using Microsoft.Extensions.Logging;
using RPT.Models;
using RPT.Repositories;

namespace RPT.Services;

public class GoalService : IGoalService
{
    private readonly IGoalRepo _goalRepository;
    private readonly ILogger<GoalService> _logger;

    public GoalService(IGoalRepo goalRepository, ILogger<GoalService> logger)
    {
        _goalRepository = goalRepository;
        _logger = logger;
    }

    public async Task<bool> CreateGoalAsync(GoalDetails goal)
{
    _logger.LogInformation($"Attempting to create goal for Profile ID: {goal.ProfileId}");
    return await _goalRepository.CreateGoalAsync(goal);
}

    public async Task<Goal?> GetGoalByIdAsync(int profileId)
{

    _logger.LogInformation($"Attempting to fetch goal for Profile ID: {profileId}");
    return await _goalRepository.GetGoalByIdAsync(profileId);
}   
}
