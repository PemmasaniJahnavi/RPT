using RPT.Models;
namespace RPT.Services
{
    public interface ISignupService
    {
      bool Signup(Profile profile);  
    }
}

