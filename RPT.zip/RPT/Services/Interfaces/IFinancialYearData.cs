using RPT.Models;

namespace RPT.Services
{
public interface IFinancialYearDataService
{
    Task<bool> CreateFinancialYearDataAsync(FinancialYearData financialData);
    Task<IEnumerable<FinancialData>> GetFinancialYearDataByGoalIdAsync(int goalId);
   
}
}
