using RPT.Models;
namespace RPT.Services
{
    public interface IProfileService
    {
         Task<Profile?> LoginAsync(string username, string password);
    }
}