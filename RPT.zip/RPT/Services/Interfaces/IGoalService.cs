using RPT.Models;
namespace RPT.Services;

    public interface IGoalService
    {
      Task<bool> CreateGoalAsync(GoalDetails goal);
      Task<Goal?> GetGoalByIdAsync(int id);   
    }