namespace RPT.Models
{
    public class FinancialYearData
    {
        public int ProfileId { get; set; }
        public int Id { get; set; }
        public int Year { get; set; }
        public decimal MonthlyInvestment { get; set; }
    }
}