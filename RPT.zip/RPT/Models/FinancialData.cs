namespace RPT.Models
{
    public class FinancialData
    {
        public int Year { get; set; }
        public decimal MonthlyInvestment { get; set; }
        public int Month { get; set; }
    }
}