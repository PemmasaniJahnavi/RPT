using System.Data;
using MySqlConnector;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using RPT.Models;

namespace RPT.Repositories;

public class ProfileRepo : IProfileRepo
{
    private readonly string _connectionString;
    private readonly ILogger<ProfileRepo> _logger;

    public ProfileRepo(IConfiguration configuration, ILogger<ProfileRepo> logger)
    {
        _connectionString = configuration.GetConnectionString("RetirementDatabase")?? throw new InvalidOperationException("Missing connection string in configuration.");
        _logger = logger;
    }

    public async Task<Profile?> LoginAsync(string username, string password)
{
    if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
    {
        _logger.LogWarning("Username or password is null or empty.");
        return null;
    }

    try
    {
        await using var conn = new MySqlConnection(_connectionString);
        await conn.OpenAsync();

        using var cmd = new MySqlCommand("CALL ValidateLogin(@UserName, @Password)", conn);
        cmd.Parameters.AddWithValue("@UserName", username);
        cmd.Parameters.AddWithValue("@Password", password);

        await using var reader = await cmd.ExecuteReaderAsync();
        if (await reader.ReadAsync())
        {
            return new Profile
            {
                ProfileId = reader.GetInt32("ProfileId"),
                FirstName = reader.GetString("FirstName"),
                LastName = reader.GetString("LastName"),
                Age = reader.GetInt32("Age"),
                Gender = reader.GetString("Gender"),
                UserName = reader.GetString("UserName"),
            };
        }

        return null;
    }
    catch (MySqlException ex)
    {
        _logger.LogError($"SQL Error: {ex.Message}");
        return null;
    }
    catch (Exception ex)
    {
        _logger.LogError($"Unexpected Error: {ex.Message}");
        return null;
    }
}

}
