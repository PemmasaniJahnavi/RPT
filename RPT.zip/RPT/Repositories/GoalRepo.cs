using System.Data;
using MySqlConnector;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using RPT.Models;

namespace RPT.Repositories;

public class GoalRepo : IGoalRepo
{
    private readonly string _connectionString;
    private readonly ILogger<GoalRepo> _logger;

    public GoalRepo(IConfiguration configuration, ILogger<GoalRepo> logger)
    {
        _connectionString = configuration.GetConnectionString("RetirementDatabase")?? throw new InvalidOperationException("Missing connection string in configuration.");
        _logger = logger;
    }

    public async Task<bool> CreateGoalAsync(GoalDetails goal)
{
    if (goal == null|| goal.ProfileId <= 0 || goal.CurrentAge <= 0 || goal.RetirementAge <= 0 ||goal.RetirementAge<=goal.CurrentAge
        ||goal.TargetSavings <= 0 || goal.CurrentSavings < 0)
    {
        _logger.LogWarning("Invalid input received.");
        return false;
    }

    try
    {
        await using var conn = new MySqlConnection(_connectionString);
        await conn.OpenAsync();

        using var cmd = new MySqlCommand("CALL CreateGoal(@ProfileId, @CurrentAge, @RetirementAge, @TargetSavings, @CurrentSavings)", conn);
        cmd.Parameters.AddWithValue("@ProfileId", goal.ProfileId);
        cmd.Parameters.AddWithValue("@CurrentAge", goal.CurrentAge);
        cmd.Parameters.AddWithValue("@RetirementAge", goal.RetirementAge);
        cmd.Parameters.AddWithValue("@TargetSavings", goal.TargetSavings);
        cmd.Parameters.AddWithValue("@CurrentSavings", goal.CurrentSavings);

        return await cmd.ExecuteNonQueryAsync() > 0;
    }
    catch (Exception ex)
    {
        _logger.LogError($"Error: {ex.Message}");
        return false;
    }
}

    public async Task<Goal?> GetGoalByIdAsync(int profileId)
    {
      if (profileId <= 0)
    {
        _logger.LogWarning("Invalid Profile ID.");
        return null;
    }

    try
    {
        await using var conn = new MySqlConnection(_connectionString);
        await conn.OpenAsync();

        using var cmd = new MySqlCommand("CALL GetGoal(@ProfileId)", conn);
        cmd.Parameters.AddWithValue("@ProfileId", profileId);

        await using var reader = await cmd.ExecuteReaderAsync();
        if (await reader.ReadAsync())
        {
               return new Goal { 
                GoalId = reader.GetInt32("GoalId"),               
                ProfileId = reader.GetInt32("ProfileId"),
                CurrentAge = reader.GetInt32("CurrentAge"), 
                RetirementAge = reader.GetInt32("RetirementAge"), 
                TargetSavings = reader.GetDecimal("TargetSavings"),
                MonthlyContribution = reader.GetDecimal("MonthlyContribution"),
                CurrentSavings = reader.GetDecimal("CurrentSavings") 
            };
        }

        return null;
    }
    catch (Exception ex)
    {
        _logger.LogError($"Error: {ex.Message}");
        return null;
    }
}


}
