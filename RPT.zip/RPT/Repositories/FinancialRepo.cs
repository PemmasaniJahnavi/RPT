using System.Data;
using MySqlConnector;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using RPT.Models;

namespace RPT.Repositories;

public class FinancialRepo : IFinancialRepo
{
    private readonly string _connectionString;
    private readonly ILogger<FinancialRepo> _logger;

    public FinancialRepo(IConfiguration configuration, ILogger<FinancialRepo> logger)
    {
        _connectionString = configuration.GetConnectionString("RetirementDatabase")?? throw new InvalidOperationException("Missing connection string in configuration.");
        _logger = logger;
    }

    public async Task<bool> CreateFinancialYearDataAsync(FinancialYearData fData)
    {
    if (fData == null||fData.GoalId<=0|| fData.Year<=2024 || fData.Month<1 
    || fData.MonthlyInvestment<0 || fData.Month>12)
    {
        _logger.LogWarning("Invalid input received");
        return false;
    }

    try
    {
        await using var conn = new MySqlConnection(_connectionString);
        await conn.OpenAsync();

        using var cmd = new MySqlCommand("CALL CreateFinancialYearData(@GoalId, @Year, @MonthlyInvestment, @Month)", conn);
        cmd.Parameters.AddWithValue("@GoalId", fData.GoalId);
        cmd.Parameters.AddWithValue("@Year", fData.Year);
        cmd.Parameters.AddWithValue("@MonthlyInvestment", fData.MonthlyInvestment);
        cmd.Parameters.AddWithValue("@Month", fData.Month);

        return await cmd.ExecuteNonQueryAsync() > 0;
    }
    catch (MySqlException ex)
    {
        if (ex.Message.Contains("exists"))
        {
            _logger.LogWarning("This month entry already done.");
            return false;
        }

        _logger.LogError($"SQL Error: {ex.Message}");
        return false;
    }
    catch (Exception ex)
    {
        _logger.LogError($"Unexpected Error: {ex.Message}");
        return false;
    }
    }

public async Task<IEnumerable<FinancialData>> GetFinancialYearDataByGoalIdAsync(int goalId)
{
   var financialDataList = new List<FinancialData>();
    
    if (goalId <= 0)
    {
        _logger.LogWarning("Invalid goalId received.");
        return financialDataList;
    }
   
    try
    {
        await using var conn = new MySqlConnection(_connectionString);
        await conn.OpenAsync();

        using var cmd = new MySqlCommand("CALL GetFinancialYearData(@GoalId)", conn);
        cmd.Parameters.AddWithValue("@GoalId", goalId);

        using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            financialDataList.Add(new FinancialData
            {
                Month = reader.GetInt32("Month"),
                Year = reader.GetInt32("Year"),            
                MonthlyInvestment = reader.GetDecimal("MonthlyInvestment")
            });
        }
    }
    catch (Exception ex)
    {
        _logger.LogError($"Error: {ex.Message}");
    }

    return financialDataList;
}
}
