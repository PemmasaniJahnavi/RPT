using RPT.Models;

namespace RPT.Repositories
{
    public interface IGoalRepo
    {
        Task<bool> CreateGoalAsync(GoalDetails goal);
        Task<Goal?> GetGoalByIdAsync(int profileId);       
    }
}
