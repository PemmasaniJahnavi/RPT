using RPT.Models;

namespace RPT.Repositories
{
    public interface IFinancialRepo
    {
        Task<bool> CreateFinancialYearDataAsync(FinancialYearData financialData);
        Task<IEnumerable<FinancialData>> GetFinancialYearDataByGoalIdAsync(int goalId);
    }
}
