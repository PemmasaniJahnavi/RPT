using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using RPT.Services;
using RPT.Repositories;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllers();

// Add configuration service
var configuration = builder.Configuration;
builder.Services.AddSingleton(configuration);

// Add logging service
builder.Services.AddLogging();

// Add CORS service
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAngular",
        builder => builder.WithOrigins("http://localhost:4200") // Replace with your Angular app URL
                          .AllowAnyMethod()
                          .AllowAnyHeader()
                          .AllowCredentials());
});

// Register services
builder.Services.AddScoped<IGoalService, GoalService>();
builder.Services.AddScoped<IProfileService, ProfileService>();
builder.Services.AddScoped<IFinancialYearDataService, FinancialYearDataService>();
builder.Services.AddScoped<IProgressService, ProgressService>();

// Register repositories
builder.Services.AddScoped<IGoalRepo, GoalRepo>();
builder.Services.AddScoped<IProfileRepo, ProfileRepo>();
builder.Services.AddScoped<IFinancialRepo, FinancialRepo>();
builder.Services.AddScoped<IProgressRepo, ProgressRepo>();

// Add Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Configure middleware
app.UseHttpsRedirection();

// Enable CORS
app.UseCors("AllowAngular");

app.UseAuthorization();
app.MapControllers();
app.Run();
