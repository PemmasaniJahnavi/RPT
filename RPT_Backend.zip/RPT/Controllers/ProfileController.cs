using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RPT.Models;
using RPT.Services;

namespace RPT.Controllers;

[ApiController]
[Route("api/login")]
public class ProfileController : ControllerBase
{
    private readonly IProfileService _profileService;
    private readonly ILogger<ProfileController> _logger;

    public ProfileController(IProfileService profileService, ILogger<ProfileController> logger)
    {
        _profileService = profileService;
        _logger = logger;
    }
    
    [HttpPost]
    public async Task<IActionResult> ValidateLoginAsync([FromBody] Login profile)
    {
        _logger.LogInformation($"Request received for Login from user: {profile?.UserName}"); 

        if (profile == null || string.IsNullOrWhiteSpace(profile.UserName) || string.IsNullOrWhiteSpace(profile.Password))
        {
            _logger.LogWarning("Invalid login request received.");
            return StatusCode(StatusCodes.Status400BadRequest, "Invalid request. Enter the username and password.");
        }

        try
        {
            var nprofile = await _profileService.LoginAsync(profile.UserName, profile.Password);
            if (nprofile != null)
            {   
                _logger.LogInformation($"Login success for the user {profile.UserName}"); 
                return StatusCode(StatusCodes.Status200OK, nprofile);
            }

            _logger.LogWarning($"Login failed for username: {profile.UserName}");
            return StatusCode(StatusCodes.Status401Unauthorized, "Invalid UserName or Password");
        }
        catch (Exception ex)
        {
            _logger.LogError($"Exception: {ex.Message}");
            return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error.");
        }
    }
}
