using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RPT.Models;
using RPT.Services;

namespace RPT.Controllers;

[ApiController]
[Route("api/progress")]
public class ProgressController : ControllerBase
{
    private readonly IProgressService _progressService;
    private readonly ILogger<ProgressController> _logger;

    public ProgressController(IProgressService progressService, ILogger<ProgressController> logger)
    {
        _progressService = progressService;
        _logger = logger;
    }

    [HttpGet("{goalId}")]
    public async Task<IActionResult> GetProgress(int goalId)
    {
        _logger.LogInformation($"Received request to fetch progress for Goal ID: {goalId}");

        if (goalId <= 0)
        {
            _logger.LogWarning("Invalid Goal ID.");
            return BadRequest("Invalid Goal ID.");
        }

        try
        {
            var progress = await _progressService.GetProgressByGoalIdAsync(goalId);
            if (progress == null)
            {
                _logger.LogWarning($"No progress found for Goal ID: {goalId}");
                return NotFound("Progress data not found.");
            }

            return Ok(progress);
        }
        catch (Exception ex)
        {
            _logger.LogError($"Exception: {ex.Message}");
            return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error.");
        }
    }
}
