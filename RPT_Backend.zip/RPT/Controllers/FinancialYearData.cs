using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RPT.Models;
using RPT.Services;

namespace RPT.Controllers;

[ApiController]
[Route("api/financialdata")]
public class FinancialYearDataController : ControllerBase
{
    private readonly IFinancialYearDataService _financialService;
    private readonly ILogger<FinancialYearDataController> _logger;

    public FinancialYearDataController(IFinancialYearDataService financialService, ILogger<FinancialYearDataController> logger)
    {
        _financialService = financialService;
        _logger = logger;
    }

    [HttpPost("create")]
    public async Task<IActionResult> CreateFinancialDataAsync([FromBody] FinancialYearData newData)
    {
        _logger.LogInformation($"Received request to create financial year data for GoalID: {newData.GoalId}");

        if (newData == null)
        {
            _logger.LogWarning("Invalid input: Request body is null.");
            return BadRequest("Invalid input. Request body is missing.");
        }
        if (newData.GoalId <= 0)
        {
            _logger.LogWarning("Invalid input: Goal ID must be greater than 0.");
            return BadRequest("Goal ID must be greater than 0.");
        }
        if (newData.Year < 2025)
        {
            _logger.LogWarning("Invalid input: Year must be 2025 or later.");
            return BadRequest("Year must be 2025 or later.");
        }
        if (newData.Month < 1 || newData.Month > 12)
        {
            _logger.LogWarning("Invalid input: Month must be between 1 and 12.");
            return BadRequest("Month must be between 1 and 12.");
        }
        if (newData.Month < DateTime.Now.Month && newData.Year == DateTime.Now.Year)
        {
            _logger.LogWarning("Invalid input: Month cannot be less than the current month in the same year.");
            return BadRequest($"Month must be {DateTime.Now.Month} or later in the current year.");
        }
        if (newData.MonthlyInvestment < 0)
        {
            _logger.LogWarning("Invalid input: Monthly contribution cannot be negative.");
            return BadRequest("Monthly contribution cannot be negative.");
        }

        //getting goal data TargetSavings.
        var goalData = await _financialService.GetGoalByIdAsync(newData.GoalId);
        if (goalData == null)
        {
            _logger.LogWarning($"No goal found with GoalID: {newData.GoalId}");
            return BadRequest($"No goal found for Goal ID: {newData.GoalId}");
        }

        // getting progress data TotalContribution
        var progressData = await _financialService.GetTotalContributionByGoalIdAsync(newData.GoalId);
        var totalContribution = progressData?.TotalContribution ?? 0;

        //Monthly Investment limit check.
        var maxAllowedContribution = goalData.TargetSavings - totalContribution;
        if (newData.MonthlyInvestment > maxAllowedContribution)
        {
            _logger.LogWarning($"Monthly contribution exceeds allowed limit ({maxAllowedContribution}).");
            return BadRequest($"Monthly contribution must be ≤ {maxAllowedContribution}.");
        }

        try
        {
            var success = await _financialService.CreateFinancialYearDataAsync(newData);
            if (success)
            {
                _logger.LogInformation("Creation of FinancialData successful.");
                return StatusCode(StatusCodes.Status201Created, "Financial data created successfully.");
            }

            _logger.LogError("Creation of FinancialData failed.");
            return StatusCode(StatusCodes.Status500InternalServerError, "Error in creation of financial data.");
        }
        catch (Exception ex)
        {
            _logger.LogError($"Exception in CreateFinancialData: {ex.Message}");
            return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error.");
        }
    }


    [HttpGet("maxAllowedContribution/{goalId}")]
public async Task<IActionResult> GetMaxAllowedContributionAsync(int goalId)
{
    _logger.LogInformation($"Fetching max allowed contribution for Goal ID: {goalId}");

    var goalData = await _financialService.GetGoalByIdAsync(goalId);
    if (goalData == null)
    {
        _logger.LogWarning($"No goal found for Goal ID: {goalId}");
        return BadRequest($"No goal found for Goal ID: {goalId}");
    }

    var progressData = await _financialService.GetTotalContributionByGoalIdAsync(goalId);
    var totalContribution = progressData?.TotalContribution ?? 0;

    var maxAllowedContribution = goalData.TargetSavings - totalContribution;

    return Ok(maxAllowedContribution);
}

}
