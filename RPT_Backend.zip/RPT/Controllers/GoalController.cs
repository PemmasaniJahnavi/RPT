using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RPT.Models;
using RPT.Services;

namespace RPT.Controllers;

[ApiController]
[Route("api/goal")]
public class GoalController : ControllerBase
{
    private readonly IGoalService _goalService;
    private readonly ILogger<GoalController> _logger;

    public GoalController(IGoalService goalService, ILogger<GoalController> logger)
    {
        _goalService = goalService;
        _logger = logger;
    }

    [HttpPost("create")]
    public async Task<ActionResult<Goal>> CreateGoalAsync([FromBody] GoalDetails newGoal)
    {
        _logger.LogInformation($"Received request to create goal for Profile ID: {newGoal?.ProfileId}");

        if (newGoal == null || !ModelState.IsValid || newGoal.ProfileId <= 0)
        {
            _logger.LogWarning("Invalid input received.");
            return BadRequest("Invalid input values. Please check!");
        }

        if (newGoal.CurrentAge <= 0 || newGoal.RetirementAge <= 0)
                 {
            _logger.LogWarning("Age cant be zero or negative.");
            return BadRequest("Age cant be zero or negative.");
        }
        if(newGoal.RetirementAge <= newGoal.CurrentAge)
        {
            _logger.LogWarning("Retirement age must be greater than current age.");
            return BadRequest("Retirement age must be greater than current age.");
        }
        if(newGoal.TargetSavings <= newGoal.CurrentSavings)
        {
            _logger.LogWarning("Target savings must be greater than current savings.");
            return BadRequest("Target savings must be greater than current savings.");
        }
        if(newGoal.CurrentSavings < 0)
        {
            _logger.LogWarning("Current savings should be >=0.");
            return BadRequest("Current savings should be >=0");
        }
        if(newGoal.TargetSavings <= 0 )
        {
            _logger.LogWarning("Target savings should be >0.");
            return BadRequest("Target savings should be >0");
        }

        try
        {
            Goal? createdGoal = await _goalService.CreateGoalAsync(newGoal);

            if (createdGoal != null)
            {
                _logger.LogInformation($"Goal created successfully for Profile ID: {newGoal.ProfileId}");
                return Created($"api/goal/{createdGoal.ProfileId}", createdGoal);
            }

            _logger.LogWarning("Goal creation failed.");
            return StatusCode(StatusCodes.Status500InternalServerError, new { Message = "Goal creation failed." });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred while creating a goal.");
            return StatusCode(StatusCodes.Status500InternalServerError, new { Message = "Internal Server Error." });
        }
    }

    [HttpGet("fetch/{profileId}")]
    public async Task<ActionResult<Goal?>> GetGoalAsync(int profileId)
    {
        _logger.LogInformation($"Fetching goal for Profile ID: {profileId}");

        if (profileId <= 0)
        {
            _logger.LogWarning("Invalid Profile ID received.");
            return BadRequest(new { Message = "Invalid Profile ID. Please check!" });
        }

        try
        {
            Goal? goal = await _goalService.GetGoalByProfileIdAsync(profileId);

            if (goal != null)
            {
                _logger.LogInformation($"Goal found for Profile ID: {profileId}");
                return Ok(goal);
            }

            _logger.LogWarning("No goal found for the given Profile ID.");
            return NotFound(new { Message = "No goal found for the given Profile ID." });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exception occurred while fetching the goal.");
            return StatusCode(StatusCodes.Status500InternalServerError, new { Message = "Internal Server Error." });
        }
    }
}

