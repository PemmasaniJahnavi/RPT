using System.Data;
using MySqlConnector;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using RPT.Models;

namespace RPT.Repositories
{
    public class GoalRepo : IGoalRepo
    {
        private readonly string _connectionString;
        private readonly ILogger<GoalRepo> _logger;

        public GoalRepo(IConfiguration configuration, ILogger<GoalRepo> logger)
        {
            _connectionString = configuration.GetConnectionString("RetirementDatabase") 
                ?? throw new InvalidOperationException("Missing connection string in configuration.");
            _logger = logger;
        }

        public async Task<Goal?> CreateGoalAsync(GoalDetails newGoal)
        {
            try
            {
                using var connection = new MySqlConnection(_connectionString);
                await connection.OpenAsync();

                
                using var cmd = new MySqlCommand("CALL CreateGoal(@ProfileId, @CurrentAge, @RetirementAge, @TargetSavings, @CurrentSavings);", connection);
                cmd.Parameters.AddWithValue("@ProfileId", newGoal.ProfileId);
                cmd.Parameters.AddWithValue("@CurrentAge", newGoal.CurrentAge);
                cmd.Parameters.AddWithValue("@RetirementAge", newGoal.RetirementAge);
                cmd.Parameters.AddWithValue("@TargetSavings", newGoal.TargetSavings);
                cmd.Parameters.AddWithValue("@CurrentSavings", newGoal.CurrentSavings);

                
                using var reader = await cmd.ExecuteReaderAsync();
                
                if (await reader.ReadAsync())
                {
                    return new Goal
                    {
                        GoalId = reader.GetInt32("GoalId"),
                        ProfileId = reader.GetInt32("ProfileId"),
                        CurrentAge = reader.GetInt32("CurrentAge"),
                        RetirementAge = reader.GetInt32("RetirementAge"),
                        TargetSavings = reader.GetDecimal("TargetSavings"),
                        MonthlyContribution = reader.GetDecimal("MonthlyContribution"),
                        CurrentSavings = reader.GetDecimal("CurrentSavings")
                    };
                }

                return null; 
            }
            catch (MySqlException ex)
            {
                _logger.LogError(ex, "Database Exception occurred while creating a goal.");
                return null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected Exception occurred while creating a goal.");
                return null;
            }
        }


        public async Task<Goal?> GetGoalByProfileIdAsync(int profileId)
        {
            try
            {
                using var connection = new MySqlConnection(_connectionString);
                await connection.OpenAsync();

                using var cmd = new MySqlCommand("CALL GetGoal(@ProfileId);", connection);
                cmd.Parameters.AddWithValue("@ProfileId", profileId);

                using var reader = await cmd.ExecuteReaderAsync();

                if (await reader.ReadAsync())
                {
                    return new Goal
                    {
                        GoalId = reader.GetInt32("GoalId"),
                        ProfileId = reader.GetInt32("ProfileId"),
                        CurrentAge = reader.GetInt32("CurrentAge"),
                        RetirementAge = reader.GetInt32("RetirementAge"),
                        TargetSavings = reader.GetDecimal("TargetSavings"),
                        MonthlyContribution = reader.GetDecimal("MonthlyContribution"),
                        CurrentSavings = reader.GetDecimal("CurrentSavings")
                    };
                }

                return null;
            }
            catch (MySqlException ex)
            {
                _logger.LogError(ex, "Database Exception occurred while fetching the goal.");
                return null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected Exception occurred while fetching the goal.");
                return null;
            }
        }
    }
}
