using System.Data;
using MySqlConnector;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using RPT.Models;

namespace RPT.Repositories;

public class FinancialRepo : IFinancialRepo
{
    private readonly string _connectionString;
    private readonly ILogger<FinancialRepo> _logger;

    public FinancialRepo(IConfiguration configuration, ILogger<FinancialRepo> logger)
    {
        _connectionString = configuration.GetConnectionString("RetirementDatabase") ?? throw new InvalidOperationException("Missing connection string in configuration.");
        _logger = logger;
    }

    public async Task<Goal?> GetGoalByIdAsync(int goalId)
    {
        await using var conn = new MySqlConnection(_connectionString);
        await conn.OpenAsync();

        using var cmd = new MySqlCommand("SELECT GoalId, TargetSavings FROM Goals WHERE GoalId = @GoalId", conn);
        cmd.Parameters.AddWithValue("@GoalId", goalId);

        using var reader = await cmd.ExecuteReaderAsync();
        if (await reader.ReadAsync())
        {
            return new Goal
            {
                GoalId = reader.GetInt32(0),
                TargetSavings = reader.GetDecimal(1)
            };
        }
        return null;
    }

    public async Task<Progress?> GetTotalContributionByGoalIdAsync(int goalId)
    {
        await using var conn = new MySqlConnection(_connectionString);
        await conn.OpenAsync();

        using var cmd = new MySqlCommand("SELECT TotalContribution FROM Progress WHERE GoalId = @GoalId", conn);
        cmd.Parameters.AddWithValue("@GoalId", goalId);

        using var reader = await cmd.ExecuteReaderAsync();
        if (await reader.ReadAsync())
        {
            return new Progress
            {
                GoalId = goalId,
                TotalContribution = reader.IsDBNull(0) ? 0 : reader.GetDecimal(0)
            };
        }
        return null;
    }

    public async Task<bool> CreateFinancialYearDataAsync(FinancialYearData fData)
    {
        if (fData == null || fData.GoalId <= 0 || fData.Year < 2025 || fData.Month < 1 || fData.Month > 12 || fData.MonthlyInvestment < 0)
        {
            _logger.LogWarning("Invalid input received for CreateFinancialYearData.");
            return false;
        }

        try
        {
            var goalData = await GetGoalByIdAsync(fData.GoalId);
            if (goalData == null)
            {
                _logger.LogWarning($"No goal found with GoalID: {fData.GoalId}");
                return false;
            }
            var progressData = await GetTotalContributionByGoalIdAsync(fData.GoalId);
            var totalContribution = progressData?.TotalContribution ?? 0;

            var maxAllowedContribution = goalData.TargetSavings - totalContribution;
            if (fData.MonthlyInvestment > maxAllowedContribution)
            {
                _logger.LogWarning($"Monthly contribution exceeds allowed limit ({maxAllowedContribution}).");
                return false;
            }

            await using var conn = new MySqlConnection(_connectionString);
            await conn.OpenAsync();

            using var cmd = new MySqlCommand("CALL CreateFinancialYearData(@GoalId, @Year, @MonthlyInvestment, @Month)", conn);
            cmd.Parameters.AddWithValue("@GoalId", fData.GoalId);
            cmd.Parameters.AddWithValue("@Year", fData.Year);
            cmd.Parameters.AddWithValue("@MonthlyInvestment", fData.MonthlyInvestment);
            cmd.Parameters.AddWithValue("@Month", fData.Month);

            return await cmd.ExecuteNonQueryAsync() > 0;
        }
        catch (MySqlException ex)
        {
            if (ex.Message.Contains("previous"))
            {
                _logger.LogWarning("Entry cannot be made for past months.");
                return false;
            }

            _logger.LogError($"SQL Error: {ex.Message}");
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogError($"Unexpected Error: {ex.Message}");
            return false;
        }
    }
}
