using RPT.Models;

namespace RPT.Repositories
{
    public interface IGoalRepo
    {
        Task<Goal?> CreateGoalAsync(GoalDetails goal);
        Task<Goal?> GetGoalByProfileIdAsync(int profileId);    
    }
}
