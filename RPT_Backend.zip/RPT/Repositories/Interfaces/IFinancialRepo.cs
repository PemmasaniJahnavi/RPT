using RPT.Models;

namespace RPT.Repositories
{
    public interface IFinancialRepo
    {
        Task<Goal?> GetGoalByIdAsync(int goalId);
        Task<Progress?> GetTotalContributionByGoalIdAsync(int goalId);
        Task<bool> CreateFinancialYearDataAsync(FinancialYearData financialData);
    }
}
