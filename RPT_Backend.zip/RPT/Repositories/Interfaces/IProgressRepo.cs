using RPT.Models;
namespace RPT.Repositories;

public interface IProgressRepo
{
    Task<Progress?> GetProgressByGoalIdAsync(int goalId);
}
