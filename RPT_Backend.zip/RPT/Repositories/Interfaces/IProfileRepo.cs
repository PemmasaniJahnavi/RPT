using RPT.Models;

namespace RPT.Repositories
{
    public interface IProfileRepo
    {
        Task<Profile?> LoginAsync(string username, string password);
    }
}
