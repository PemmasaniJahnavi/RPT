using System.Data;
using MySqlConnector;
using Microsoft.Extensions.Logging;
using RPT.Models;

namespace RPT.Repositories;

public class ProgressRepo : IProgressRepo
{
    private readonly string _connectionString;
    private readonly ILogger<ProgressRepo> _logger;

    public ProgressRepo(IConfiguration configuration, ILogger<ProgressRepo> logger)
    {
        _connectionString = configuration.GetConnectionString("RetirementDatabase") 
            ?? throw new InvalidOperationException("Missing connection string.");
        _logger = logger;
    }

    public async Task<Progress?> GetProgressByGoalIdAsync(int goalId)
    {
        if (goalId <= 0)
        {
            _logger.LogWarning("Invalid Goal ID.");
            return null;
        }

        try
        {
            await using var conn = new MySqlConnection(_connectionString);
            await conn.OpenAsync();

            using var cmd = new MySqlCommand("CALL GetProgressByGoalId(@GoalId)", conn);
            cmd.Parameters.AddWithValue("@GoalId", goalId);

            await using var reader = await cmd.ExecuteReaderAsync();
            if (await reader.ReadAsync())
            {
                return new Progress
                {
                    GoalId = reader.GetInt32("GoalId"),
                    TargetSavings = reader.GetDecimal("TargetSavings"),
                    TotalContribution = reader.GetDecimal("TotalContribution"),
                    ProgressPercentage = reader.GetDecimal("ProgressPercentage")
                };
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error fetching progress: {ex.Message}");
        }

        return null;
    }
}
