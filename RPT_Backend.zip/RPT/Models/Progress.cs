namespace RPT.Models;

public class Progress
{
    public int GoalId { get; set; }
    public decimal TargetSavings { get; set; }
    public decimal TotalContribution { get; set; }
    public decimal ProgressPercentage { get; set; }
}
