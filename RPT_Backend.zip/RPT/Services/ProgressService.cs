using Microsoft.Extensions.Logging;
using RPT.Models;
using RPT.Repositories;

namespace RPT.Services;

public class ProgressService : IProgressService
{
    private readonly IProgressRepo _progressRepo;
    private readonly ILogger<ProgressService> _logger;

    public ProgressService(IProgressRepo progressRepo, ILogger<ProgressService> logger)
    {
        _progressRepo = progressRepo;
        _logger = logger;
    }

    public async Task<Progress?> GetProgressByGoalIdAsync(int goalId)
    {
        _logger.LogInformation($"Fetching progress for Goal ID: {goalId}");
        return await _progressRepo.GetProgressByGoalIdAsync(goalId);
    }
}
