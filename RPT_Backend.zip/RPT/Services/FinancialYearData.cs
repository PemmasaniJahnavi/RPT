using Microsoft.Extensions.Logging;
using RPT.Models;
using RPT.Repositories;

namespace RPT.Services;

public class FinancialYearDataService : IFinancialYearDataService
{
    private readonly IFinancialRepo _financialYearDataRepository;
    private readonly ILogger<FinancialYearDataService> _logger;

    public FinancialYearDataService(IFinancialRepo financialYearDataRepository, ILogger<FinancialYearDataService> logger)
    {
        _financialYearDataRepository = financialYearDataRepository;
        _logger = logger;
    }

    
    public async Task<Goal?> GetGoalByIdAsync(int goalId)
    {
        _logger.LogInformation($"Fetching goal details for Goal ID: {goalId}");
        return await _financialYearDataRepository.GetGoalByIdAsync(goalId);
    }

    
    public async Task<Progress?> GetTotalContributionByGoalIdAsync(int goalId)
    {
        _logger.LogInformation($"Fetching total contribution for Goal ID: {goalId}");
        return await _financialYearDataRepository.GetTotalContributionByGoalIdAsync(goalId);
    }

    
    public async Task<bool> CreateFinancialYearDataAsync(FinancialYearData financialData)
    {
        _logger.LogInformation($"Attempting to create financial year data for Goal ID: {financialData.GoalId}");
        return await _financialYearDataRepository.CreateFinancialYearDataAsync(financialData);
    }
}
