using Microsoft.Extensions.Logging;
using RPT.Models;
using RPT.Repositories;

namespace RPT.Services;

public class GoalService : IGoalService
{
    private readonly IGoalRepo _goalRepository;
    private readonly ILogger<GoalService> _logger;

    public GoalService(IGoalRepo goalRepository, ILogger<GoalService> logger)
    {
        _goalRepository = goalRepository;
        _logger = logger;
    }

    public async Task<Goal?> CreateGoalAsync(GoalDetails goal)
{
    _logger.LogInformation($"Attempting to create goal for Profile ID: {goal.ProfileId}");
    return await _goalRepository.CreateGoalAsync(goal);
}
 
  public async Task<Goal?> GetGoalByProfileIdAsync(int profileId)
    {
        _logger.LogInformation($"Checking goal for Profile ID: {profileId}");
        return await _goalRepository.GetGoalByProfileIdAsync(profileId);
    }
   
}
