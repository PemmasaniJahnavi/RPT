using RPT.Models;
namespace RPT.Services;

    public interface IGoalService
    {
      Task<Goal?> CreateGoalAsync(GoalDetails goal);
      Task<Goal?> GetGoalByProfileIdAsync(int profileId);
    }