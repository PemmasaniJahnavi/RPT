using RPT.Models;
namespace RPT.Services;

public interface IProgressService
{
    Task<Progress?> GetProgressByGoalIdAsync(int goalId);
}
