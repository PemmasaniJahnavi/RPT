using RPT.Models;

namespace RPT.Services
{
public interface IFinancialYearDataService
{
    Task<Goal?> GetGoalByIdAsync(int goalId); 
    Task<Progress?> GetTotalContributionByGoalIdAsync(int goalId);
    Task<bool> CreateFinancialYearDataAsync(FinancialYearData financialData);
}
}
